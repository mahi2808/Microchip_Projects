#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=PWM_EVSYS_TIM_ADC.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/PWM_EVSYS_TIM_ADC.production.hex
