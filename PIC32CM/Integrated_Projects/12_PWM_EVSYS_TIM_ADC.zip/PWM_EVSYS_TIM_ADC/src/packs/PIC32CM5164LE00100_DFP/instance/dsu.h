/*
 * Instance header file for PIC32CM5164LE00100
 *
 * Copyright (c) 2024 Microchip Technology Inc. and its subsidiaries.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/* file generated from device description file (ATDF) version 2022-09-09T06:08:26Z */
#ifndef _PIC32CMLE00_DSU_INSTANCE_
#define _PIC32CMLE00_DSU_INSTANCE_


/* ========== Instance Parameter definitions for DSU peripheral ========== */
#define DSU_DMAC_ID_DCC0                         (2)        /* DMAC ID for DCC0 register */
#define DSU_DMAC_ID_DCC1                         (3)        /* DMAC ID for DCC1 register */
#define DSU_INSTANCE_ID                          (33)       /* Instance index for DSU */

#endif /* _PIC32CMLE00_DSU_INSTANCE_ */
