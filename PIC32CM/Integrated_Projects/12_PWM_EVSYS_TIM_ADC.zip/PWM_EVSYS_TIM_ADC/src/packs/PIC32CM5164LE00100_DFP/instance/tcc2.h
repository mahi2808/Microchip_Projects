/*
 * Instance header file for PIC32CM5164LE00100
 *
 * Copyright (c) 2024 Microchip Technology Inc. and its subsidiaries.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/* file generated from device description file (ATDF) version 2022-09-09T06:08:26Z */
#ifndef _PIC32CMLE00_TCC2_INSTANCE_
#define _PIC32CMLE00_TCC2_INSTANCE_


/* ========== Instance Parameter definitions for TCC2 peripheral ========== */
#define TCC2_CC_NUM                              (2)        /* Number of Compare/Capture units */
#define TCC2_DITHERING                           (0)        /* Dithering feature implemented */
#define TCC2_DMAC_ID_MC0                         (34)       /* Indexes of DMA Match/Compare 0 trigger */
#define TCC2_DMAC_ID_MC1                         (35)       /* Indexes of DMA Match/Compare 1 trigger */
#define TCC2_DMAC_ID_OVF                         (33)       /* DMA overflow/underflow/retrigger trigger */
#define TCC2_DTI                                 (0)        /* Dead-Time-Insertion feature implemented */
#define TCC2_GCLK_ID                             (26)       /* Index of Generic Clock */
#define TCC2_INSTANCE_ID                         (76)       /* Instance index for TCC2 */
#define TCC2_MASTER_SLAVE_MODE                   (0)        /* TCC type 0 : NA, 1 : Master, 2 : Slave */
#define TCC2_OTMX                                (0)        /* Output Matrix feature implemented */
#define TCC2_OW_NUM                              (2)        /* Number of Output Waveforms */
#define TCC2_PG                                  (0)        /* Pattern Generation feature implemented */
#define TCC2_SIZE                                (16)       
#define TCC2_SWAP                                (0)        /* DTI outputs swap feature implemented */

#endif /* _PIC32CMLE00_TCC2_INSTANCE_ */
